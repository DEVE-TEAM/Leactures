package com.example.asus.leactures;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView biolgy = (TextView) findViewById(R.id.bilogy);
        biolgy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent biointet = new Intent(MainActivity.this, Bilogy.class);
                startActivity(biointet);
            }
        });
        final TextView chemistry = (TextView) findViewById(R.id.chemistry);
        chemistry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent chemistr = new Intent(MainActivity.this, Chemistry.class);
                startActivity(chemistr);
            }
        });
        TextView phisc = (TextView) findViewById(R.id.physical);
        phisc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent physic = new Intent(MainActivity.this, Physics.class);
                startActivity(physic);

            }
        });


    }

}
