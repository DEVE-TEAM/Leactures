package com.example.asus.leactures;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by ASUS on 12/23/2017.
 */

public class LeacturAdapter extends ArrayAdapter<leactur> {


    public LeacturAdapter(Activity context, ArrayList<leactur> lec) {

        super(context, 0, lec);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item , parent, false);
        }

        leactur currentleactur = getItem(position);

        TextView nameTextView = (TextView) listItemView.findViewById(R.id.leacnum);
        nameTextView.setText(currentleactur.getLeactuenum());


        TextView numberTextView = (TextView) listItemView.findViewById(R.id.lectitle);

        numberTextView.setText(currentleactur.getLeacturetitel());

        ImageView iconView = (ImageView) listItemView.findViewById(R.id.list_item_icon);

        iconView.setImageResource(currentleactur.getImageResourceId());

        ImageView play = (ImageView) listItemView.findViewById(R.id.play);

        play.setImageResource(currentleactur.getImageResourcId());



        return listItemView;
    }
}
