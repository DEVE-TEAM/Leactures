package com.example.asus.leactures;

import android.view.View;
import android.widget.Button;

/**
 * Created by ASUS on 12/23/2017.
 */

public class leactur {
    private String leactuenum;
    private String leacturetitel;
    private int mImageResourceId;
    private int mImageResourcId;

    public leactur(String LNum, String LTitle, int imageResourceId, int imageResourcId) {
        leactuenum = LNum;
        leacturetitel = LTitle;
        mImageResourceId = imageResourceId;
        mImageResourcId = imageResourcId;
    }

    public String getLeactuenum() {
        return leactuenum;
    }


    public String getLeacturetitel() {
        return leacturetitel;
    }

    public int getImageResourceId() {
        return mImageResourceId;
    }

    public int getImageResourcId() {
        return mImageResourcId;
    }


}
