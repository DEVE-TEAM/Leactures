package com.example.asus.leactures;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class Physics extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leactu_list);
        Button backbutton =(Button)findViewById(R.id.buttom_id);
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent o =new Intent(Physics.this,MainActivity.class);
                startActivity(o);

            }
        });
        ArrayList<leactur> lec =new ArrayList<>();
        lec.add(new leactur("first leactur"," Physics and Measurement",R.drawable.physic,R.drawable.play));
        lec.add(new leactur("second leactur"," Vectors",R.drawable.physic,R.drawable.play));
        lec.add(new leactur("theard leactur"," The Force and Laws of Motion",R.drawable.physic,R.drawable.play));
        lec.add(new leactur("fourth leactur"," Static Equilibrium and Elasticity",R.drawable.physic,R.drawable.play));
        lec.add(new leactur("fifth leactur"," Energy, Work and Power",R.drawable.physic,R.drawable.play));
        lec.add(new leactur("six leactur","  Fluid Mechanics",R.drawable.physic,R.drawable.play));

        LeacturAdapter adapter = new LeacturAdapter(this,lec);
        ListView listView = (ListView)findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
