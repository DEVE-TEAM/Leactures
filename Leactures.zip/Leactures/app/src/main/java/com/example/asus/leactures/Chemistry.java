package com.example.asus.leactures;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class Chemistry extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leactu_list);
        Button backbutton =(Button)findViewById(R.id.buttom_id);
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent o =new Intent(Chemistry.this,MainActivity.class);
                startActivity(o);

            }
        });
        ArrayList<leactur> lec = new ArrayList<>();
        lec.add(new leactur("first leactur", " Quantum Chemistry", R.drawable.cham, R.drawable.play));
        lec.add(new leactur("second leactur", " Electrochemistry", R.drawable.cham, R.drawable.play));
        lec.add(new leactur("theard leactur", " Organic Chemistry ", R.drawable.cham, R.drawable.play));
        lec.add(new leactur("fourth leactur", " Kinetic Chemistry", R.drawable.cham, R.drawable.play));
        lec.add(new leactur("fifth leactur", " Biochemistry", R.drawable.cham, R.drawable.play));
        lec.add(new leactur("six leactur", "  Quantitative Analysis", R.drawable.cham, R.drawable.play));

        LeacturAdapter adapter = new LeacturAdapter(this, lec);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);


    }
}
